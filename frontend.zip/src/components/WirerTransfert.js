import React from "react";

const WirerTransfert = () => {
  return <div>To be completed</div>;
};

export default WirerTransfert;