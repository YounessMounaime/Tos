import React from "react";

const Home = () => {
  return <div>To be completed</div>;
};

export default Home;